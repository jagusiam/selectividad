package selectividad;

/**
 * SELECTIVIDAD: El programa asigna las carerras a los candidatos a la universidad 
 * teniendo en cuenta sus preferencias (tres opciones) realizandolo por orden 
 * de nota y según las plazas disponibles.
 * Los datos de los estudiantes y carreras se leen de dos ficheros diferentes.
 * @author aga
 */
public class Asignacion {
    
    public static void main(String[] args) {
    //Declarar e instanciar el array de objetos de la clase Carrera   
        Carrera carreras[];
        carreras = new Carrera[60];

    //Declarar e instanciar el array de objetos de la clase Estudiante
        Estudiante estudiantes [];
        estudiantes = new Estudiante [200];
     
         // cargar el array con los datos de las carreras    
        for (Carrera carrera : carreras) {
            carrera.leerDatos (carreras);
        }       
        
         //mostrar los datos de los carreras por pantalla
        //para probar si el programa lee el fichero y aloja bien los datos 
        //en el array
        Carrera.mostrarDatos(carreras);       
        
        
        // cargar el array con los datos de los estudiantes    
        for (Estudiante estudiante : estudiantes) {
            estudiante.leerDatos (estudiantes);
        }
              
        //mostrar los datos de los estudiantes por pantalla
        //para probar si el programa lee el fichero y aloja bien los datos 
        //en el array
        Estudiante.mostrarDatos(estudiantes);
        
              
    }
    
}
    
    
    

