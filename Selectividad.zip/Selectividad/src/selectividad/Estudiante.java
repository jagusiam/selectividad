package selectividad;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author aga
 */
public class Estudiante {
    // atributos
    int dni;
    int nota;
    int pref1;
    int pref2;
    int pref3;
    
    // metodo constructor
    public Estudiante (int dni, int nota, int pref1, int pref2, int pref3) {
        this.dni = dni;
        this.nota = nota;
        this.pref1 = pref1;
        this.pref2 = pref2;
        this.pref3 = pref3;        
    }
    
    //método cargar datos - desde un fichero
    public void leerDatos(Estudiante estudiantes[]) {
        FileInputStream fichero; 
        BufferedReader buffer;
        InputStreamReader isr;     
        
        try {  
        fichero = new FileInputStream("F:\\AGA\\dam confinamiento\\PROGRAMACIÓN\\7. Selectividad\\festudiantes.txt");
        isr = new InputStreamReader(fichero, "UTF8");
        buffer = new BufferedReader(isr);
        
        String linea;
        
        /*Recorremos el array de estudiantes para ir alojando en él los datos
        de los objetos a medida de que vayamos extrayendolos del fichero*/
        for (int i=0; i<estudiantes.length; i++) {
        
            
        //Mientras haya una línea en el fichero, el programa la lee  
            while ((linea = buffer.readLine()) != null) {
            
            /*Ya que necesitamos extraer los datos de los estudiantes por
            separado troceamos la línea con la función split y alojamos
            los elementos en un array de Strings*/
                if (linea.length() != 0) { // filtra líneas en blanco
                 String datos[] = linea.split(" ");//espacio en blanco es el punto de separación
                 
            /*Ahora queremos asignar los elementos extraídos del fichero y 
                 alojados en el array auxiliar String datos[] a las variables
                 de la clase Estuduante y alojarlos en el array de objetos
                 Estudiante estudiantes []*/
            //Las variables son de tipo int - hay que convertir Strings to int
                        dni=Integer.parseInt(datos[0]);
                        nota=Integer.parseInt(datos[1]);
                        pref1=Integer.parseInt(datos[2]);
                        pref2=Integer.parseInt(datos[3]);
                        pref3=Integer.parseInt(datos[4]);
                        
                //Cargamos los datos en cada celda del array estudiantes
                    estudiantes[i] = new Estudiante (dni, nota, pref1, pref2, pref3);  
                }    
        
            }   
        
        }
        
         buffer.close();   /* cerramos el fichero */
        } catch (IOException ex) {
            ex.printStackTrace();
        }
     
                
    }
    
    
    /*un método creado para comprobar si funciona la carga de fichero 
    imprimiendo datos por pantalla*/
    public static void mostrarDatos(Estudiante estudiantes[]) {

        for (Estudiante aux : estudiantes) {
            System.out.println(" * - * - * - * ");
            System.out.println("DNI: " + aux.dni + " >> NOTA: " + aux.nota 
                    + " >> PREF1: " + aux.pref1 + " >> PREF2: " + aux.pref2 
                    + ">> PREF3: " + aux.pref3);
        }
        System.out.println(" * - * - * - * ");

    }    
     
    
}
